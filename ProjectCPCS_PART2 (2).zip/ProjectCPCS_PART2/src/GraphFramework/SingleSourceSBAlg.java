
package GraphFramework;
import  AirFrieghtApp.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;

public class SingleSourceSBAlg extends ShortestPathAlgorithm{
    // Data Fields
         int[] distance;
         int[] previousVertex ;
	String[] path;
       
	int infinity = Integer.MAX_VALUE; 
    
    public SingleSourceSBAlg(Graph graph) {
        super(graph);
    }

    

   
        
	public void computeDijkstraAlg(Vertex source) {
//Call the graph class to get VerticesNo and assign it into distance array 
		 distance = new int[graph.getVerticesNo()]; 
//Call the graph class to get VerticesNo and assign it into previous Vertex array 
		 previousVertex = new int[graph.getVerticesNo()]; 
                boolean[] visitedVertex = new boolean[graph.getVerticesNo()];
                path = new String[graph.getVertices().length]; 
		for (int i = 0; i < graph.getVertices().length; i++) {
			distance[i] = infinity;
		}
                // make all  vertices = -1 in the begining
                for (int i = 0; i < graph.getVertices().length; i++) {
			previousVertex[i] = -1;
		}
                // make all  vertices false--> unvisited in the begining
                for (int i = 0; i < graph.getVertices().length; i++) {
			visitedVertex[i] = false;
		}
                // let the distance source = 0
                distance[source.getLabel()] = 0;
		
 // To store unvisited vertices ,create queue
        PriorityQueue<Vertex> pq = new PriorityQueue<>(graph.getVerticesNo(), new Comparator<Vertex>() {
            
            @Override
            public int compare(Vertex v1, Vertex v2) {
                return distance[v1.getLabel()] - distance[v2.getLabel()];
            }
        });
          // Add the source to queue
        pq.add(source);
               //Dijkstra's  loop 
        while (!pq.isEmpty()) {
            Vertex curr = pq.poll();
            visitedVertex[curr.getLabel()] = true;
           // traverse all the adjacent edges of currentV
            for (Edge e : curr.getAdjList()) {
                Vertex v = e.getTarget();
                
                if (!visitedVertex[v.getLabel()] && distance[curr.getLabel()] != Integer.MAX_VALUE &&
                        distance[curr.getLabel()] + e.getWeight() < distance[v.getLabel()]) {
                    distance[v.getLabel()] = distance[curr.getLabel()] + e.getWeight();
                    
                    
                    previousVertex[v.getLabel()] = curr.getLabel();
                    
                    pq.remove(v);
                    pq.add(v);
                }
            }
           
        }
        
 
           
        
    }
        @Override
    public void displayInfo(Vertex source) {
           
             
            System.out.println("Shortest paths from location " + source.displayInfo() + ":");
            for (int i = 0; i < graph.getVerticesNo(); i++) {
                if (distance[i] == Integer.MAX_VALUE) {
  //  is there a path from  source -->  current , if (no)--> print has no path.
                    System.out.println(source.displayInfo() + " has no path to " + graph.getVertices()[i].displayInfo());
                    continue;
                } else {
          //  is there a path from  source -->  current? , if (YES)--> print path&lengths 
                    System.out.print("loc."+source.displayInfo()+" : "+ " city "+(source.getLabel()+1)+" - ");
                }
                LinkedList<Integer> path = new LinkedList<>();
                int curr = i;
                while (curr != -1) {
// Add the current vertex into path
                    path.addFirst(curr);
    // Get the previous vertex  and assign it on the  current vertex
                    curr = previousVertex[curr];
                }
                for (int j = 1; j < path.size(); j++) {
                    System.out.print("loc."+graph.getVertices()[path.get(j)].displayInfo()+" : "+ "city "+(graph.getVertices()[path.get(j)].getLabel()+1)+" - ");
                    if (j < path.size() - 1) {
                        System.out.print("");
                    }
                }
                
                Route r=new Route();
                
                System.out.print( r.displayInfo(distance[i]));
               
                System.out.println();
            }
           
    }
}

