
package GraphFramework;

public class ShortestPathAlgorithm {
    Graph graph;

    public ShortestPathAlgorithm(Graph graph) {
        this.graph = graph;
    }
   public void displayInfo(Vertex source) {
        
    }
    
}
