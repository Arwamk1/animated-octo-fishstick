
package GraphFramework;


public class DBAllSourceSPAlg extends ShortestPathAlgorithm {
int[] dist;
    public DBAllSourceSPAlg(Graph graph) {
        super(graph);
    }
    
  public void computeDijkstraBasedSPAlg(Graph graph,int choice){
SingleSourceSBAlg obj =new SingleSourceSBAlg(graph);// Create graph Object 
        
       
           
            
            for (int i = 0; i < graph.getVertices().length; i++) {
                
                 obj.computeDijkstraAlg(graph.getVertices()[i]);
                 if(choice==1){
                 obj.displayInfo(graph.getVertices()[i]);
                 }
               
            }
            
            
       
        
    }
}
