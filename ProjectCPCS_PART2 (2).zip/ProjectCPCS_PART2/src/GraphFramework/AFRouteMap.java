
package GraphFramework;
import AirFrieghtApp.Location;
import AirFrieghtApp.Route;
import GraphFramework.*;

public class AFRouteMap extends Graph{
    public AFRouteMap() {
    }

    public AFRouteMap(int verticesNO, int edgeNo, boolean isDigraph) {
        super(verticesNO, edgeNo, isDigraph);
    }

    
    @Override
    Edge createEdge(Vertex source, Vertex target, int weight) {
        return new Route(source, target, weight);
    }

    @Override
    Vertex createVertex(int label) {
        return  new Location(label);
    }
    
}
