
package GraphFramework;

import AirFrieghtApp.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.regex.Pattern;

public abstract class Graph {
    // data fields:

    private int verticesNO;
    private int edgeNo;
    private boolean isDigraph;
    private Vertex [] vertices;
//constrctors:

    public Graph(int verticesNO, int edgeNo, boolean isDigraph) {
        this.verticesNO = verticesNO;
        this.edgeNo = edgeNo;
        this.isDigraph = isDigraph;
        this.vertices = new Vertex[verticesNO];
       
    }

    public Graph() {
    }
        //Getter&Setters

    public int getVerticesNo() {
        return verticesNO;
    }

    public void setVerticesNo(int verticesNO) {
        this.verticesNO = verticesNO;
    }

    public int getEdgesNo() {
        return edgeNo;
    }

    public void setEdgesNo(int edgeNo) {
        this.edgeNo = edgeNo;
    }

    public boolean getIsDiagraph() {
        return isDigraph;
    }

    public void setIsDiagraph(boolean isDigraph) {
        this.isDigraph = isDigraph;
    }

    public Vertex [] getVertices() {
        return vertices;
    }

    public void setVertices(Vertex [] vertices) {
        this.vertices = vertices;
    }
    


    public void makeGraph(int v, int e) {

        for (int i = 0; i < verticesNO; i++) {
                     //assigning  Vertex object for all vertices 

            vertices[i] = createVertex(i);  
         
        }
        
        //Does the graph connect?
       
        for (int i = 1; i < verticesNO ; i++) {
            //1-generate random wight
            int randomWeight = (int) (1 + Math.random() * 20);  //2- assign it to  edge

            //3- Add  the edge ...
            addEdge(vertices[i-1].getLabel(), vertices[i].getLabel(), randomWeight); 
        }
        
        int totalNumberEdge = edgeNo -( verticesNO-1 );
        int i = 0; //counter of edges 
        while( i <totalNumberEdge ){
            //choose a source  and target randomly
            int sourceLable = (int) (Math.random() * (verticesNO));
            int targetLabel = (int) (Math.random() * (verticesNO));
            if (sourceLable == targetLabel ) { 
                continue; 
            }
          
    			for(int j=0; j < vertices[sourceLable].getAdjList().size(); j++) {
	
                            if(vertices[sourceLable].getAdjList().get(j).getTarget().getLabel() != targetLabel) {
    					
    					break; 
    					
    				} 
    			} 
        
    			addEdge(vertices[sourceLable].getLabel(), vertices[targetLabel].getLabel(), (int) (1 + Math.random() * 10));
				i++;
        }      
    
        

    }
    			           // make sure the the edges are not duplicated 
    public boolean isDuplicated(int SourceId, int targetID) {
        return false;

    }

    
    public void readGraphFromFile(File inputGraph) throws FileNotFoundException {
       //  to read from file

            Scanner input = new Scanner(inputGraph); 
            
            String GraphType = input.nextLine(); 
            
            if(GraphType.equalsIgnoreCase("digraph 0")) {
                isDigraph= false;//false because 0 mean -->un direct
            }
            else if (GraphType.equalsIgnoreCase("digraph 1")) {
            	isDigraph = true; //true because 1 mean --> direct
            }
            
    		int totalNumVertices= input.nextInt(); 
    		int totalNumEdge= input.nextInt();
    		
    		if(!isDigraph) {
    			totalNumEdge *= 2;
    		}
              		
            vertices = new Vertex[totalNumVertices];
           
            
            while(edgeNo < totalNumEdge) {
                
                // Read the source , target as char  and weight as intger from file 
                char source = input.next().charAt(0);
               
                
                char target = input.next().charAt(0);
               
                int weight = input.nextInt();
                
                addEdge(source-65, target-65, weight); 
             
                
                                
            }
            input.close();


        
    }
    
    public Edge addEdge(int source, int target, int wieght) {

        Graph g = new AFRouteMap();
        
        if(vertices[source] == null){
             verticesNO++;
           vertices[source] =  g.createVertex(source);
           
       
    }
        
          if(vertices[target] == null){
                     verticesNO++;
         vertices[target]=  g.createVertex(target);
                 
        
    }
        Edge e = g.createEdge(vertices[source],vertices[ target], wieght);
        edgeNo++;
       
        vertices[source].getAdjList().add(e);
        

        if (isDigraph == false) {
            e = g.createEdge(vertices[target], vertices[source], wieght);
           edgeNo += 2;
           vertices [target].getAdjList().add(e);

        } 
        return e;

    }

    abstract Edge createEdge(Vertex source, Vertex target, int wieght) ;

    abstract Vertex createVertex(int label);

    public Vertex addVertex(int Vertex) {
     
      Vertex v = new Vertex(Vertex);
      
        return v;
 
    }

   
    
}