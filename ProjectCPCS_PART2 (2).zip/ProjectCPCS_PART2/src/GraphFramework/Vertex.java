
package GraphFramework;

import java.util.LinkedList;

public class Vertex {
        // data fields:

    private String name;
    private Vertex previosVertex;
    private int label;
    private boolean isVisited= false; 
    private LinkedList<Edge> adjList; 
    //constrctors:

    public Vertex() {
        adjList = new LinkedList<Edge>() ;
    }
    public Vertex(int label) {
        this.label = label;
        this.adjList = new LinkedList<>();
    }
    //Getter&Setters

public int getLabel() {
        return label;
    }
    public void setLabel(int label) {
        this.label = label;
    }
    public LinkedList<Edge> getAdjList() {
        return adjList;
    }

    public void setAdjList(LinkedList<Edge> adjList) {
        this.adjList = adjList;
    }

    public boolean isVisited() {
        return isVisited;
    }

    public void setVisited(boolean isVisited) {
        this.isVisited = isVisited;
    }

    public Vertex getPreviosVertex() {
        return previosVertex;
    }

    public void setPreviosVertex(Vertex previosVertex) {
        this.previosVertex = previosVertex;
    }

    

    @Override
    public String toString() {
        return name;
    }

    
    
    public String displayInfo() {
     return null;
        
    }
}