package AirFrieghtApp;



import GraphFramework.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class AirFrieghtApp {
    
    
    public static void main(String[] args) throws FileNotFoundException {
        Scanner in = new Scanner(System.in);//to read from user 
        //data fields:
        int choice; 
        int CasesNM;
        boolean IsDirect=false;
        int Vnum=0;
        int Enum=0;
        Graph graph ;
        DBAllSourceSPAlg ShortPathObj;
        Graph AireMap;
   
      
//print the main menuand ask user to chhoose
        do {
            System.out.println("\n----------------------- WELCOME TO Dijkstra ALGORITHM ANALYSIS ----------------------\n "
                    + "If you want to read graph from file type (1):  "
                    + "\n If you want to enter graph data type(2):  "
                    + "\n If you want to exit type (0): ");
            choice = in.nextInt();
      
            if (choice == 1) { //requirement 1 
                System.out.print("\n\n\t\t\t");
                System.out.println("-Requirement 1 Using Read From Graph function-");
                ///read from file  
                File inputFile = new File("inputGraph.txt"); 
                // Create  Object from AFRouteMap
                   AireMap = new AFRouteMap();
                   // call method readGraphFromFile to take the data from Graph Class
                  AireMap.readGraphFromFile(inputFile); 
              
                System.out.print("The routes from location A to the rest of the locations are:\n\n");
                ShortPathObj = new DBAllSourceSPAlg(AireMap); // Create  Object
                ShortPathObj.computeDijkstraBasedSPAlg(AireMap,choice);
        
                
                
               

            }  if (choice == 2) { // requirement 2 
            System.out.print("\t\t\t");
            System.out.println("-Requirement 2 Using Make Graph function-");
            
	
	  System.out.println("Cases of Edges(m) and Vertcies(n):");
	  System.out.println("(1) n= 2000, m= 10000");
          System.out.println("(2) n= 3000, m= 15000");
          System.out.println("(3) n= 4000, m= 20000");
	  System.out.println("(4) n= 5000, m= 25000");
          System.out.println("(5) n= 6000, m= 30000");
          
            
             System.out.print("Select your Test Option -> ");
	    CasesNM = in.nextInt(); 
             

while (!(1 < 1 || 5 > 5)){
	      if(CasesNM==1) {
	              Vnum = 2000;
	              Enum = 10000;
                      break;
	          }
	            
	
              else if (CasesNM==2){
	              Vnum = 3000;
	              Enum = 15000;
                       break;
	          }
	            
	          else if (CasesNM==3){
	              Vnum = 4000;
	              Enum = 20000;
                       break;
	          }
	          else if (CasesNM==4){
	              Vnum = 5000;
	              Enum = 25000;
                       break;
	          }
	          else if (CasesNM==5){
	              Vnum = 6000;
	              Enum = 30000;
                       break;
                  }
                 else{
	              System.out.println("Option not found.");
	              System.out.print("Select your Test Option -> ");
	       
	              break;
              }}
	
 
  // Create An Object 
                Graph AirMap = new AFRouteMap(Vnum, Enum, false);  
                
                AirMap.makeGraph(Vnum, Enum); 
                
                ShortPathObj = new DBAllSourceSPAlg(AirMap);
                ShortPathObj.computeDijkstraBasedSPAlg(AirMap,choice);
                
              
                // --------------------------------------------- DBALLSourceSPAlg ------------------------------------------------ //
     
	  
	  ShortPathObj = new DBAllSourceSPAlg(AirMap); 
      double DBALLstartTime = System.currentTimeMillis();       
      ShortPathObj.computeDijkstraBasedSPAlg(AirMap,choice); 
      double DBALLfinishTime = System.currentTimeMillis();
      //Calculate final time  
      double DBALLFinalTime = DBALLfinishTime - DBALLstartTime;
      System.out.println("Running time for DBALL Source Shortest path Algorithm: "+ DBALLFinalTime+" ms.");

    

                
            }	
      

             

        }while (choice != 0); 
        //Exit from system 
           if(choice==0){
        System.out.println("The system closed");
        System.exit(0);
        }
        in.close();
      
    
   

}
}