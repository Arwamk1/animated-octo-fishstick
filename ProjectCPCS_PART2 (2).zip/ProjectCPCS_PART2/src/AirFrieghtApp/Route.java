
package AirFrieghtApp;

import GraphFramework.*;

public class Route extends Edge{

    public Route() {
        
    }
    

		
		public Route(Vertex source, Vertex target, int weight) {
			super(source, target, weight);
			
		} 
	    @Override
	     public String displayInfo(int Routelength) {
	    	return " : Route length: " +  Routelength;
	    } 
	
	} // End of Class