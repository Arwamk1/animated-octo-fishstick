
package AirFrieghtApp;

import GraphFramework.*;


public class Location extends Vertex{
    // Data Fields
	private String city ;

   
//constructor
	public Location(int label) {
		super(label);
		this.city = String.valueOf((char)(label+65));
	}
	
	public String getCity() {
		return city;
    } 
	@Override
    public String displayInfo() {
		return city;
    } 

} // End of class